This readme file was generated on 2026-01-30 by Alaina L Pearce


# GENERAL INFORMATION

* Title of Dataset: 1990 - Yogurt Sensory Specific Satiety (SSS) by Age

## Author/Principal Investigator Information
Name: Barbara J Rolls

ORCID: 0000-0003-2374-1517

Institution: Pennsylvania State University 

Email: bjr4@psu.edu

## Author/Data Librarian
Name: Alaina L. Pearce

ORCID: 0000-0003-3157-6566

Institution: Pennsylvania State University

Email: azp271@psu.edu

# Published Works

* Rolls, Barbara J., and Teresa M. McDermott. "Effects of age on sensory-specific satiety." The American journal of clinical nutrition 54, no. 6 (1991): 988-996.

# Data Collection Information
* Date of data collection: 1990
* Location: Johns Hopkins University

# SHARING/ACCESS INFORMATION

## Licenses/restrictions
* CC-BY

## Requested citation for this dataset: 

Rolls, Barbara J., & Pearce, Alaina L. (2026) Yogurt SSS by Age 1990 [Dataset]. ScholarSphere.

# DATA OVERVIEW

Dataset was compiled according to the Psych-DS (0.1.0) and validated using the psychds R package.

Leonard B (2026). psychds: Psych-DS Dataset Creator, Data Dictionary Wizard, and Validator. R package version 0.1.0, commit a05943723c55990a1e7ef7692f80c624e0c5bf6b, <https://github.com/psych-ds/psychds-r>.

## Directory Structure

* dataset_description.json - contains dataset description and variable definitions; validated by R package psychds
* documentation - ontains original documentation about study and methods converted to an open text format
* materials - contains original materials documents such as data collection sheets and researcher scripts converted to an open text format
* publication - contains open access verion of peer-reviewed publication
* data - contains de-identified dataset

## Additional related data

Additional may have been collected during the original study and may be referenced in original documents; however, the current datasets contains all data that was preserved. It includes participant intake, rating data, and measures on self-reported eating attitudes. 

# Study Protocol

## Description of methods 

The goal of this study was to examin the role of age on sensory specific satiety. These data are from a study that included 2 visits. Participants varied in age across 4 different age groups. At each visit, they compleated visual analog scales to report their current state (e.g., hunger, thirst, nausea, fullness, etc.) before and after eating. Participants were served 2 different amounts of yogurt, with the amount of yogurt served at a visit counterballanced across participants. Participants were asked to taste a series of foods and use a visual analog scale to rate pleasentness of food attributes before and after eating the yogurt. The goal of this study was to examine the role of age on sensory specific satiety. 

## Software

Data were collected in person on paper-pencil forms. VAS scales were measured by hand and recorded. The original data and documentation and material were converted from Lotus 1, 2, 3.

Data files are stored as .csv files and text documents are stored in .odt, which is an open text format created by LibreOffice.


## DATA-SPECIFIC INFORMATION FOR: assay-demo_data.csv
Contains participant characteristics
* Number of variables: 14
* Number of cases/rows: 96
* Variable List: see assay-demo_data.json
* Missing data codes: n/a

## DATA-SPECIFIC INFORMATION FOR: assay-sss_data.csv
Contains participant ratings and intake to compute sensory specific satiety
* Number of variables: 192
* Number of cases/rows: 110
* Variable List: see assay-sss_data.json
* Missing data codes: n/a

## DATA-SPECIFIC INFORMATION FOR: assay-sss_data.csv
Contains participant ratings and intake to compute sensory specific satiety. Data is in long format with participant repeated for visit
* Number of variables: 192
* Number of cases/rows: 110
* Variable List: see assay-sss_data.json
* Missing data codes: n/a

## DATA-SPECIFIC INFORMATION FOR: assay-upsit_data.csv
Contains participant ratings and overall performance on the University of Pennsylvania Smell Identification Test
* Number of variables: 96
* Number of cases/rows: 44
* Variable List: see assay-upsit_data.json
* Missing data codes: n/a

## DATA-SPECIFIC INFORMATION FOR: assay-foodpref_data.csv
Contains participant ratings on a list of foods to examine food preferences
* Number of variables: 96
* Number of cases/rows: 132
* Variable List: see assay-foodpref_data.json
* Missing data codes: n/a