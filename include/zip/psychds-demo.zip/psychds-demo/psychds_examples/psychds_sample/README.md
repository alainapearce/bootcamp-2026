This readme file was generated on 2026-01-23 by Alaina L Pearce


# GENERAL INFORMATION

* Title of Dataset: 1988 - Whole Vs Parts

## Author/Principal Investigator Information
Name: Barbara J Rolls

ORCID: 0000-0003-2374-1517

Institution: Pennsylvania State University 

Email: bjr4@psu.edu

## Author/Data Librarian
Name: Alaina L. Pearce

ORCID: 0000-0003-3157-6566

Institution: Pennsylvania State University

Email: azp271@psu.edu

# Published Works

* No peer-reviewed publication was ever published using these data

# Data Collection Information
* Date of data collection: 1988
* Location: Johns Hopkins University

# SHARING/ACCESS INFORMATION

## Licenses/restrictions
* CC-BY

## Published Works
No publications resulted from these data.

## Requested citation for this dataset: 

Rolls, Barbara J., Pearce, Alaina L., (2026) Whole versus Parts 1988 [Dataset]. ScholarSphere.

# DATA OVERVIEW

Dataset was compiled according to the Psych-DS (0.1.0) and validated using the psychds R package.

Leonard B (2026). psychds: Psych-DS Dataset Creator, Data Dictionary Wizard, and Validator. R package version 0.1.0, commit a05943723c55990a1e7ef7692f80c624e0c5bf6b, <https://github.com/psych-ds/psychds-r>.

## Directory Structure

* dataset_description.json - contains dataset description and variable definitions
* documentation - ontains original documentation about study and methods converted to an open text format
* materials - contains original materials documents such as data collection sheets and researcher scripts converted to an open text format
* data - contains de-identified dataset

## Additional related data

Additional data was collected during the original study and may be referenced in original documents; however, the current data is all that was preserved. It includes participant intake and rating data. Missing data includes information about sex, body mass index, and questionniare data.

# Study Protocol

## Description of methods 

These data are from a study that included 2 counterbalanced visits and a followup discharge session.  The counterballanced condition was whether participants were served the sandwhiches as whole units or cut into peices. Participants included men and women without overweight or obesity who were not dieting. Visits were conducted at approximately 11:30 in the morning. Participants were given visual analog (VAS) scales to rate their hunger, thirst, fullness, desire to eat, and how much they thought they could eat (i.e., propective consumption).  They were then asked to rate the pleasantness of the taste and their desire to eat a sample of ham and swiss cheese sandwich with lettuce and mustard on rye. Participants were then either presented with 4 whole ham and swiss cheese sandwiches on rye (held together with a toothpick) or with these same sandwiches cut into 9 little squares, each held together with a toothpick.  They were also given a 550 g glass of cold water and a timer.  They were told to eat as much as they wanted wihtin 20 min and to ask for more if they so desired. They were not allowed to read, do any work or to socialize during this time. All VAS ratings were then repeated after the participants finished eating the sandwhiches. Total intake was computed by weight the sandwhiches and water before and after the meal.

## Software

Data were collected in person on paper-pencil forms. VAS scales were measured by hand and recorded. The original data and documentation and material were converted from Lotus 1, 2, 3.

Data files are stored as .csv files and text documents are stored in .odt, which is an open text format created by LibreOffice.


## DATA-SPECIFIC INFORMATION FOR: study-wholevparts_date-1988_data.csv

* Number of variables: 18
* Number of cases/rows: 102
* Variable List: see dataset_description.json
* Missing data codes: n/a
* Notes: 1 participant was excluded from the de-identified data due to inconclusive condition information
